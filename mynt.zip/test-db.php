<?php
include 'db.php';
echo "Database connection is working!";
?>
